package App;

import static spark.Spark.*;

import Services.ConcursoService;
import dao.*;

public class ConcursoApp {
	public static void main(String[] args) {
		//staticFiles.externalLocation("src/main/resources/public");
		/*DAO dao = new DAO();
		dao.conectar();*/
	}
}
