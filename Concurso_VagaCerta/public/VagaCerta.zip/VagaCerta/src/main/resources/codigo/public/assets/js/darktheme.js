document.getElementById("darkThemeButton").onclick = function() {
    document.body.classList.toggle("dark-theme");
};